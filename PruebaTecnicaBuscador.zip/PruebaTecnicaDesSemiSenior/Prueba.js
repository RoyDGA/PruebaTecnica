
function SearchUser() {
    const tagName = document.querySelector('#buscarid').value;
    
    fetch('https://api.github.com/users/'+tagName).then((res) => res.json()

    ).then((data) => {
        if ('message' in data) {
            alert('Usuario no encontrado');
            window.location.reload();
        }
        else{
            sendUser(data);
        }
        
    });
    function sendUser(user) {

        document.getElementById('id').innerHTML = user.id;
        document.getElementById('login').innerHTML = user.login; 
        document.getElementById('avatar_url').innerHTML = `<img src="${user.avatar_url}">`;
        
        var date = new Date(user.created_at);
        document.getElementById('created_at').innerHTML = date.toDateString();
        
        document.getElementById('name').innerHTML = user.name;
        document.getElementById('location').innerHTML = user.location;
        document.getElementById('twitter_username').innerHTML = `@${user.twitter_username}`;
        document.getElementById('blog').innerHTML = user.blog;
        document.getElementById('public_repos').innerHTML = user.public_repos;
        document.getElementById('followers').innerHTML = user.followers;
        document.getElementById('following').innerHTML = user.following;
        
    }
}









